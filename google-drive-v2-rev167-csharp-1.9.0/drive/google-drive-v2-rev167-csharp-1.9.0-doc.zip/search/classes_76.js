var searchData=
[
  ['videomediametadatadata',['VideoMediaMetadataData',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1Data_1_1File_1_1VideoMediaMetadataData.html',1,'Google::Apis::Drive::v2::Data::File']]]
];

var searchData=
[
  ['watchrequest',['WatchRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1FilesResource_1_1WatchRequest.html',1,'Google::Apis::Drive::v2::FilesResource']]],
  ['watchrequest',['WatchRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1ChangesResource_1_1WatchRequest.html',1,'Google::Apis::Drive::v2::ChangesResource']]],
  ['webauthenticationbrokerusercontrol',['WebAuthenticationBrokerUserControl',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Auth_1_1OAuth2_1_1WebAuthenticationBrokerUserControl.html',1,'Google::Apis::Auth::OAuth2']]]
];

var searchData=
[
  ['newtonsoftjsonserializer',['NewtonsoftJsonSerializer',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Json_1_1NewtonsoftJsonSerializer.html',1,'Google::Apis::Json']]],
  ['nulllogger',['NullLogger',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Logging_1_1NullLogger.html',1,'Google::Apis::Logging']]]
];

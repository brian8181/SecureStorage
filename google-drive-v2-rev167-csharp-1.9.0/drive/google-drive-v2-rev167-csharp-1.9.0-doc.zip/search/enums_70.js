var searchData=
[
  ['projectionenum',['ProjectionEnum',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1FilesResource_1_1GetRequest.html#ae361bbb8f13741b0a96b5ac71ddb018e',1,'Google::Apis.Drive.v2.FilesResource.GetRequest.ProjectionEnum()'],['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1FilesResource_1_1ListRequest.html#a086c1b72ba8c6881cc2bafe587bae8bc',1,'Google::Apis.Drive.v2.FilesResource.ListRequest.ProjectionEnum()'],['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1FilesResource_1_1WatchRequest.html#ad441a2f29e4ff9d772c238562b99c8af',1,'Google::Apis.Drive.v2.FilesResource.WatchRequest.ProjectionEnum()']]]
];

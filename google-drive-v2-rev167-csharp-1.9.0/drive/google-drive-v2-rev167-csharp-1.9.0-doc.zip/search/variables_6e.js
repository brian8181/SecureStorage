var searchData=
[
  ['none',['None',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/namespaceGoogle_1_1Apis_1_1Http.html#a0bcc672afd8ddb40cf5fd149aa40f3e2',1,'Google::Apis::Http']]],
  ['notstarted',['NotStarted',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/namespaceGoogle_1_1Apis_1_1Download.html#a897888bf4394d1bc76b84acdb155ffeb',1,'Google::Apis::Download::NotStarted()'],['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/namespaceGoogle_1_1Apis_1_1Upload.html#a4c9367b7fbcb0e30d9a8fd041d98719d',1,'Google::Apis::Upload::NotStarted()']]]
];

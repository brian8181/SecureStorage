var searchData=
[
  ['legacydataresponse',['LegacyDataResponse',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/namespaceGoogle_1_1Apis_1_1Discovery.html#a26a1886e6cd81a5e19834aef318ecf85',1,'Google::Apis::Discovery']]],
  ['logger',['Logger',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Auth_1_1OAuth2_1_1UserCredential.html#a700c73ebdb274f6e1c0566ccaa774221',1,'Google::Apis::Auth::OAuth2::UserCredential::Logger()'],['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Auth_1_1OAuth2_1_1Mvc_1_1Controllers_1_1AuthCallbackController.html#ad9bf88b4ff979d77de4a10aaa8b667af',1,'Google::Apis::Auth::OAuth2::Mvc::Controllers::AuthCallbackController::Logger()']]]
];

var searchData=
[
  ['serviceaccountcredential',['ServiceAccountCredential',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Auth_1_1OAuth2_1_1ServiceAccountCredential.html',1,'Google::Apis::Auth::OAuth2']]],
  ['singleerror',['SingleError',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Requests_1_1SingleError.html',1,'Google::Apis::Requests']]],
  ['standardresponse_2dg',['StandardResponse-g',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Util_1_1StandardResponse-g.html',1,'Google::Apis::Util']]],
  ['stoprequest',['StopRequest',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1ChannelsResource_1_1StopRequest.html',1,'Google::Apis::Drive::v2::ChannelsResource']]],
  ['storagedatastore',['StorageDataStore',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Util_1_1Store_1_1StorageDataStore.html',1,'Google::Apis::Util::Store']]],
  ['stringvalueattribute',['StringValueAttribute',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Util_1_1StringValueAttribute.html',1,'Google::Apis::Util']]],
  ['stroagedatastore',['StroageDataStore',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Util_1_1Store_1_1StroageDataStore.html',1,'Google::Apis::Util::Store']]],
  ['systemclock',['SystemClock',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Util_1_1SystemClock.html',1,'Google::Apis::Util']]]
];

var searchData=
[
  ['maximumchunksize',['MaximumChunkSize',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Download_1_1MediaDownloader.html#a641b76c0708d3b27794dc859bc14c3f1',1,'Google::Apis::Download::MediaDownloader']]],
  ['minimumchunksize',['MinimumChunkSize',['http://contrib.google-api-dotnet-client.googlecode.com/hg/1.9.0/documentation/classGoogle_1_1Apis_1_1Upload_1_1ResumableUpload-g.html#a66377e21fc1eaa7ca1154ae595f9b084',1,'Google::Apis::Upload::ResumableUpload-g']]]
];
